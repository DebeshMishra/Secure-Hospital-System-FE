
export class AppConstants {
    static appName = "Secure Hospital System";
    static users = "Users";
    static logs = "Logs";
    static appointments = "Appointments";
    static profile = ['Account', 'Settings', 'Logout'];
}