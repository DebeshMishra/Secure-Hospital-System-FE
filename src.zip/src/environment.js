export class Environments {
    SERVER_URL = "http://localhost:8080"
}